export class Todo{
    sno: number | undefined
    title: string | undefined
    desc: string | undefined
    active: boolean | undefined
}